import { MatriculaPipe } from './matricula.pipe';

describe('MatriculaPipe', () => {
  it('create an instance', () => {
    const pipe = new MatriculaPipe();
    expect(pipe).toBeTruthy();
  });
});
