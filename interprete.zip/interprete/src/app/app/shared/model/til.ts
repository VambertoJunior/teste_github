export class Til {

  constructor(public id: string, public nome: string, public matricula: string,
              public telefone: string, public turno: string) {
  }


}
