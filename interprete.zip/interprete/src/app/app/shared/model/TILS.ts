import {Til} from "./til";

export const TILS: Til[] = [

];
